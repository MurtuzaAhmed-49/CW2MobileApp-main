# CW2MobileApp
cw2

[Express.js App] https://github.com/Majcioch1/CW2MobileApp

[Vue.js App] https://github.com/Majcioch1/CW2MobileApp/tree/main/public

Github Pages https://majcioch1.github.io/CW2MobileApp/

Group members: Jeremy Arland Murtuza Ahmed Karol Urbanski Milosz Gembicki Mohammed Omar Saif
